'use server';

import { getSession } from '@/lib/auth/session';
import { TYPES_CONTENU_ORGANISATION } from '@/lib/organisations/liaisons';
import {
  TYPES_ORGANISATION,
  coopterGestionnaireSchema,
  creerOrganisationSchema,
  mettreAJourOrganisationSchema,
} from '@/lib/organisations/validation';
import { slugifier, slugifierAvecSuffixeTemps } from '@/lib/slug';
import { getSupabaseServer } from '@/lib/supabase';
import { revalidatePath } from 'next/cache';
import { z } from 'zod';

type Resultat = { ok: true; slug: string } | { ok: false; message: string };
type ResultatSimple = { ok: true } | { ok: false; message: string };

/**
 * Crée une organisation (épopée réseau V2, chantier B.1).
 *
 * La personne connectée en devient le·la créateur·ice (gestionnaire provisoire
 * via `cree_par`, formalisé en B.2). La page est `active` mais NON officielle :
 * le badge est accordé séparément par l'admin (voie 2). Slug dérivé du nom avec
 * anti-collision (suffixe temporel si le slug de base est déjà pris).
 */
export async function creerOrganisationAction(donneesBrutes: unknown): Promise<Resultat> {
  const parse = creerOrganisationSchema.safeParse(donneesBrutes);
  if (!parse.success) {
    return { ok: false, message: parse.error.issues[0]?.message ?? 'Données invalides.' };
  }
  const donnees = parse.data;

  const session = await getSession();
  if (session === null) {
    return { ok: false, message: 'Tu dois être connecté·e pour créer une organisation.' };
  }
  const supabase = await getSupabaseServer();

  // Slug : base dérivée du nom, suffixe temporel si déjà pris.
  const slugBase = slugifier(donnees.nom);
  const { data: existant } = await supabase
    .from('organisation')
    .select('id')
    .eq('slug', slugBase)
    .maybeSingle();
  const slug = existant === null ? slugBase : slugifierAvecSuffixeTemps(donnees.nom);

  const { data: orgCreee, error } = await supabase
    .from('organisation')
    .insert({
      slug,
      nom: donnees.nom,
      type_organisation: donnees.type_organisation,
      description: donnees.description === '' ? null : (donnees.description ?? null),
      image_url: donnees.image_url === '' ? null : (donnees.image_url ?? null),
      cree_par: session.userId,
    })
    .select('id')
    .single();
  if (error !== null || orgCreee === null) {
    return { ok: false, message: `Création impossible : ${error?.message ?? ''}` };
  }

  // B.2 : le·la créateur·ice devient gestionnaire (via la RPC SECURITY DEFINER
  // qui vérifie qu'iel est bien le·la créateur·ice). Best-effort : si ça échoue,
  // la gestion via `cree_par` reste possible.
  await supabase.rpc('bootstrap_gestionnaire_organisation', { p_org_id: orgCreee.id });

  revalidatePath('/organisations');
  return { ok: true, slug };
}

/**
 * Met à jour la page d'une organisation (nom, type, description, logo).
 * La RLS n'autorise que les gestionnaires, le·la créateur·ice ou l'admin.
 */
export async function mettreAJourOrganisationAction(
  donneesBrutes: unknown,
): Promise<ResultatSimple> {
  const parse = mettreAJourOrganisationSchema.safeParse(donneesBrutes);
  if (!parse.success) {
    return { ok: false, message: parse.error.issues[0]?.message ?? 'Données invalides.' };
  }
  const d = parse.data;
  const session = await getSession();
  if (session === null) {
    return { ok: false, message: 'Authentification requise.' };
  }
  const supabase = await getSupabaseServer();
  const { data, error } = await supabase
    .from('organisation')
    .update({
      nom: d.nom,
      type_organisation: d.type_organisation,
      description: d.description === '' ? null : (d.description ?? null),
      image_url: d.image_url === '' ? null : (d.image_url ?? null),
    })
    .eq('id', d.id)
    .select('slug')
    .maybeSingle();
  if (error !== null) {
    return { ok: false, message: `Mise à jour impossible : ${error.message}` };
  }
  if (data === null) {
    return { ok: false, message: 'Tu n’as pas les droits pour modifier cette organisation.' };
  }
  revalidatePath(`/organisations/${data.slug}`);
  return { ok: true };
}

/**
 * Coopte une personne comme gestionnaire (par son numéro réseau M+7).
 * Réservé à un gestionnaire d'une organisation DÉJÀ officielle (voie 2) :
 * la RPC `coopter_gestionnaire_organisation` applique cette règle.
 */
export async function coopterGestionnaireAction(donneesBrutes: unknown): Promise<ResultatSimple> {
  const parse = coopterGestionnaireSchema.safeParse(donneesBrutes);
  if (!parse.success) {
    return { ok: false, message: parse.error.issues[0]?.message ?? 'Données invalides.' };
  }
  const session = await getSession();
  if (session === null) {
    return { ok: false, message: 'Authentification requise.' };
  }
  const supabase = await getSupabaseServer();

  // Résout le numéro public M+7 en identifiant de personne.
  const { data: personneId } = await supabase.rpc('personne_id_par_numero', {
    numero_cible: parse.data.numero,
  });
  if (personneId === null || typeof personneId !== 'string') {
    return { ok: false, message: 'Aucune personne ne correspond à ce numéro réseau.' };
  }

  const { data: ok } = await supabase.rpc('coopter_gestionnaire_organisation', {
    p_org_id: parse.data.org_id,
    p_personne_cible: personneId,
  });
  if (ok !== true) {
    return {
      ok: false,
      message:
        'Cooptation impossible : il faut être gestionnaire d’une organisation déjà officielle.',
    };
  }
  revalidatePath('/organisations');
  return { ok: true };
}

/** Retire un·e gestionnaire (jamais le·la dernier·e). Gestionnaire ou admin. */
export async function retirerGestionnaireAction(donneesBrutes: unknown): Promise<ResultatSimple> {
  const session = await getSession();
  if (session === null) {
    return { ok: false, message: 'Authentification requise.' };
  }
  const gestionnaireId =
    typeof donneesBrutes === 'object' && donneesBrutes !== null
      ? (donneesBrutes as { gestionnaire_id?: unknown }).gestionnaire_id
      : undefined;
  if (typeof gestionnaireId !== 'string') {
    return { ok: false, message: 'Identifiant de gestionnaire invalide.' };
  }
  const supabase = await getSupabaseServer();
  const { data: ok } = await supabase.rpc('retirer_gestionnaire', {
    p_gestionnaire_id: gestionnaireId,
  });
  if (ok !== true) {
    return {
      ok: false,
      message: 'Retrait impossible (droits insuffisants, ou c’est le·la dernier·e gestionnaire).',
    };
  }
  revalidatePath('/organisations');
  return { ok: true };
}

/**
 * Accorde ou retire le badge « officiel » d'une organisation. Réservé à
 * l'admin (voie 2). La RPC `definir_badge_officiel_organisation` vérifie le
 * droit admin.
 */
export async function definirBadgeOfficielAction(donneesBrutes: unknown): Promise<ResultatSimple> {
  const session = await getSession();
  if (session === null) {
    return { ok: false, message: 'Authentification requise.' };
  }
  const o =
    typeof donneesBrutes === 'object' && donneesBrutes !== null
      ? (donneesBrutes as { org_id?: unknown; officiel?: unknown })
      : {};
  if (typeof o.org_id !== 'string' || typeof o.officiel !== 'boolean') {
    return { ok: false, message: 'Données invalides.' };
  }
  const supabase = await getSupabaseServer();
  const { data: ok } = await supabase.rpc('definir_badge_officiel_organisation', {
    p_org_id: o.org_id,
    p_officiel: o.officiel,
  });
  if (ok !== true) {
    return { ok: false, message: 'Action réservée à l’administration.' };
  }
  revalidatePath('/organisations');
  return { ok: true };
}

/**
 * Revendique la gestion d'une organisation existante (chantier B.3). Crée une
 * demande en file d'attente, arbitrée par l'admin. La RPC vérifie qu'on n'est
 * pas déjà gestionnaire et qu'il n'y a pas déjà une demande en attente.
 */
export async function revendiquerOrganisationAction(
  donneesBrutes: unknown,
): Promise<ResultatSimple> {
  const session = await getSession();
  if (session === null) {
    return { ok: false, message: 'Tu dois être connecté·e pour revendiquer une organisation.' };
  }
  const o =
    typeof donneesBrutes === 'object' && donneesBrutes !== null
      ? (donneesBrutes as { org_id?: unknown; message?: unknown })
      : {};
  if (typeof o.org_id !== 'string') {
    return { ok: false, message: 'Organisation invalide.' };
  }
  const message = typeof o.message === 'string' ? o.message.slice(0, 1000) : '';
  const supabase = await getSupabaseServer();
  const { data: ok } = await supabase.rpc('revendiquer_organisation', {
    p_org_id: o.org_id,
    p_message: message,
  });
  if (ok !== true) {
    return {
      ok: false,
      message: 'Revendication impossible (déjà gestionnaire, ou organisation introuvable).',
    };
  }
  revalidatePath('/organisations');
  return { ok: true };
}

/**
 * Déclare qu'une organisation (gérée par le lecteur) porte un contenu
 * (chantier B.4). La RPC vérifie que le lecteur est gestionnaire de l'orga.
 */
export async function declarerContenuOrganisationAction(
  donneesBrutes: unknown,
): Promise<ResultatSimple> {
  const session = await getSession();
  if (session === null) {
    return { ok: false, message: 'Authentification requise.' };
  }
  const o =
    typeof donneesBrutes === 'object' && donneesBrutes !== null
      ? (donneesBrutes as { objet_type?: unknown; objet_id?: unknown; org_id?: unknown })
      : {};
  if (
    typeof o.objet_type !== 'string' ||
    typeof o.objet_id !== 'string' ||
    typeof o.org_id !== 'string'
  ) {
    return { ok: false, message: 'Données invalides.' };
  }
  const supabase = await getSupabaseServer();
  const { data: ok } = await supabase.rpc('declarer_contenu_organisation', {
    p_objet_type: o.objet_type,
    p_objet_id: o.objet_id,
    p_org_id: o.org_id,
  });
  if (ok !== true) {
    return {
      ok: false,
      message: 'Rattachement impossible : tu dois être gestionnaire de cette organisation.',
    };
  }
  return { ok: true };
}

/** Retire le rattachement d'un contenu à son organisation porteuse (B.4). */
export async function retirerContenuOrganisationAction(
  donneesBrutes: unknown,
): Promise<ResultatSimple> {
  const session = await getSession();
  if (session === null) {
    return { ok: false, message: 'Authentification requise.' };
  }
  const o =
    typeof donneesBrutes === 'object' && donneesBrutes !== null
      ? (donneesBrutes as { objet_type?: unknown; objet_id?: unknown })
      : {};
  if (typeof o.objet_type !== 'string' || typeof o.objet_id !== 'string') {
    return { ok: false, message: 'Données invalides.' };
  }
  const supabase = await getSupabaseServer();
  const { data: ok } = await supabase.rpc('retirer_contenu_organisation', {
    p_objet_type: o.objet_type,
    p_objet_id: o.objet_id,
  });
  if (ok !== true) {
    return { ok: false, message: 'Retrait impossible (droits insuffisants).' };
  }
  return { ok: true };
}

/**
 * Déclare l'organisation initiatrice AU MOMENT de créer un contenu (chantier
 * B.4, refinement §7.3). Trois modes :
 * - `aucune` : aucun rattachement (no-op).
 * - `existante` : rattache à une organisation que je gère déjà.
 * - `nouvelle` : crée l'organisation (j'en deviens gestionnaire) puis rattache.
 *
 * À appeler juste après la création du contenu (qui fournit son `objet_id`).
 * Best-effort : un échec ne casse pas la création du contenu (le rattachement
 * reste possible après coup via la page du contenu).
 */
const declarerInitiatriceSchema = z.object({
  objet_type: z.enum(TYPES_CONTENU_ORGANISATION),
  objet_id: z.string().uuid(),
  mode: z.enum(['aucune', 'existante', 'nouvelle']),
  org_id: z.string().uuid().optional(),
  nom: z.string().trim().min(2).max(120).optional(),
  type_organisation: z.enum(TYPES_ORGANISATION).optional(),
});

export async function declarerOrganisationInitiatriceAction(
  donneesBrutes: unknown,
): Promise<ResultatSimple> {
  const parse = declarerInitiatriceSchema.safeParse(donneesBrutes);
  if (!parse.success) {
    return { ok: false, message: parse.error.issues[0]?.message ?? 'Données invalides.' };
  }
  const d = parse.data;
  if (d.mode === 'aucune') return { ok: true };

  const session = await getSession();
  if (session === null) {
    return { ok: false, message: 'Authentification requise.' };
  }
  const supabase = await getSupabaseServer();

  let orgId: string;
  if (d.mode === 'existante') {
    if (d.org_id === undefined) {
      return { ok: false, message: 'Organisation manquante.' };
    }
    orgId = d.org_id;
  } else {
    // mode 'nouvelle' : on crée l'organisation, le·la créateur·ice devient gestionnaire.
    if (d.nom === undefined || d.nom.trim() === '') {
      return { ok: false, message: 'Nom de l’organisation manquant.' };
    }
    const slugBase = slugifier(d.nom);
    const { data: existant } = await supabase
      .from('organisation')
      .select('id')
      .eq('slug', slugBase)
      .maybeSingle();
    const slug = existant === null ? slugBase : slugifierAvecSuffixeTemps(d.nom);
    const { data: orgCreee, error } = await supabase
      .from('organisation')
      .insert({
        slug,
        nom: d.nom,
        type_organisation: d.type_organisation ?? 'autre',
        cree_par: session.userId,
      })
      .select('id')
      .single();
    if (error !== null || orgCreee === null) {
      return {
        ok: false,
        message: `Création de l’organisation impossible : ${error?.message ?? ''}`,
      };
    }
    await supabase.rpc('bootstrap_gestionnaire_organisation', { p_org_id: orgCreee.id });
    orgId = orgCreee.id;
  }

  const { data: ok } = await supabase.rpc('declarer_contenu_organisation', {
    p_objet_type: d.objet_type,
    p_objet_id: d.objet_id,
    p_org_id: orgId,
  });
  if (ok !== true) {
    return {
      ok: false,
      message: 'Rattachement impossible : tu dois être gestionnaire de cette organisation.',
    };
  }
  revalidatePath('/organisations');
  return { ok: true };
}

/** Admin : accepte (→ gestionnaire) ou refuse une revendication (chantier B.3). */
export async function traiterRevendicationAction(donneesBrutes: unknown): Promise<ResultatSimple> {
  const session = await getSession();
  if (session === null) {
    return { ok: false, message: 'Authentification requise.' };
  }
  const o =
    typeof donneesBrutes === 'object' && donneesBrutes !== null
      ? (donneesBrutes as { revendication_id?: unknown; accepter?: unknown })
      : {};
  if (typeof o.revendication_id !== 'string' || typeof o.accepter !== 'boolean') {
    return { ok: false, message: 'Données invalides.' };
  }
  const supabase = await getSupabaseServer();
  const { data: ok } = await supabase.rpc('traiter_revendication_organisation', {
    p_revendication_id: o.revendication_id,
    p_accepter: o.accepter,
  });
  if (ok !== true) {
    return { ok: false, message: 'Action réservée à l’administration.' };
  }
  revalidatePath('/admin/national/organisations');
  return { ok: true };
}
