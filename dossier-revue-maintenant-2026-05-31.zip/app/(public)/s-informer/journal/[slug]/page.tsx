import { BoutonAdminEditer } from '@/components/admin/BoutonAdminEditer';
import { MarkdownLeger } from '@/components/contenu/MarkdownLeger';
import { TexteEditableAdmin } from '@/components/contenu/TexteEditableAdmin';
import { BoutonMettreALaUne } from '@/components/home/BoutonMettreALaUne';
import { RenduRiche } from '@/components/rich-text/RenduRiche';
import { Badge, Container, Heading } from '@/components/ui';
import { estAdminCourant } from '@/lib/auth/admin';
import { lireContenuEditorial } from '@/lib/contenu-editorial';
import { formaterDateMoyenne } from '@/lib/format-date';
import { idEpingleUneHome } from '@/lib/home/une';
import { metadataPourPartage } from '@/lib/og-metadata';
import { getSupabaseServer } from '@/lib/supabase';
import type { Metadata } from 'next';
import Image from 'next/image';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { FormulaireMajEdition } from './FormulaireMajEdition';

const FALLBACKS = {
  retour: 'Retour aux numéros',
  publieLePrefix: 'Publié le',
  contenuVide: 'Contenu non encore rédigé.',
  adminSection: 'Administration (réservé admins)',
};

interface Props {
  params: Promise<{ slug: string }>;
}

async function chargerEdition(slug: string) {
  const supabase = await getSupabaseServer();
  const { data } = await supabase
    .from('journal_affiche')
    .select(
      'id, slug, titre, sous_titre, numero, format, contenu_md, contenu_html, image_couverture_url, publie_le, statut',
    )
    .eq('slug', slug)
    .maybeSingle();
  return data;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const e = await chargerEdition(slug);
  if (e === null) return { title: 'Édition introuvable' };
  return metadataPourPartage({
    objet: {
      titre: `${e.titre} (n°${e.numero}) · Maintenant Médias`,
      description: e.sous_titre ?? 'Le journal-affiche de Maintenant Médias.',
      image_url: e.image_couverture_url,
      type_objet: 'article',
    },
    cheminPage: `/s-informer/journal/${e.slug}`,
  });
}

/**
 * Page individuelle d'une édition de journal-affiche (V2.4.11).
 */
export default async function PageEditionJournal({ params }: Props) {
  const { slug } = await params;
  const [e, estAdmin, retour, publieLePrefix, contenuVide, adminSection] = await Promise.all([
    chargerEdition(slug),
    estAdminCourant(),
    lireContenuEditorial('journal.fiche.retour', { valeurMd: FALLBACKS.retour }),
    lireContenuEditorial('journal.fiche.publie_le_prefix', {
      valeurMd: FALLBACKS.publieLePrefix,
    }),
    lireContenuEditorial('journal.fiche.contenu_vide', { valeurMd: FALLBACKS.contenuVide }),
    lireContenuEditorial('journal.fiche.admin_section', { valeurMd: FALLBACKS.adminSection }),
  ]);
  if (e === null) notFound();

  // V2.6.19 : épinglage « à la une » de la home (admin, éditions publiées).
  const estEpingleUne =
    estAdmin && e.statut === 'publie' ? (await idEpingleUneHome('article')) === e.id : false;

  return (
    <Container taille="md" className="py-12">
      <p className="text-xs font-bold uppercase tracking-cap text-text-3">
        <TexteEditableAdmin
          cle="journal.fiche.retour"
          valeurInitiale={retour.valeurMd}
          estAdmin={estAdmin}
          libelle="lien retour vers liste journal"
          longueurMax={40}
        >
          {(t) => (
            <Link href="/s-informer/journal" className="hover:text-brand">
              {t}
            </Link>
          )}
        </TexteEditableAdmin>
      </p>
      <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
        <Heading niveau={1}>{e.titre}</Heading>
        <span className="flex flex-wrap items-center gap-2">
          {estAdmin && e.statut === 'publie' ? (
            <BoutonMettreALaUne
              emplacement="article"
              objetId={e.id}
              estEpingleInitial={estEpingleUne}
            />
          ) : null}
          <BoutonAdminEditer href="/admin/national">Admin</BoutonAdminEditer>
        </span>
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-2">
        <Badge variant="default">N°{e.numero}</Badge>
        <Badge variant="info">{e.format}</Badge>
        {e.publie_le !== null ? (
          <span className="text-text-3 text-xs">
            <TexteEditableAdmin
              cle="journal.fiche.publie_le_prefix"
              valeurInitiale={publieLePrefix.valeurMd}
              estAdmin={estAdmin}
              libelle="prefixe 'Publie le' (la date s'ajoute apres)"
              longueurMax={30}
            >
              {(t) => <>{t}</>}
            </TexteEditableAdmin>{' '}
            {formaterDateMoyenne(e.publie_le)}
          </span>
        ) : null}
      </div>

      {e.sous_titre !== null ? <p className="mt-3 text-text-2">{e.sous_titre}</p> : null}

      {e.image_couverture_url !== null ? (
        <div className="relative mt-6 aspect-[210/297] max-w-md overflow-hidden rounded-lg border border-border">
          <Image
            src={e.image_couverture_url}
            alt=""
            fill
            unoptimized
            sizes="(max-width: 768px) 100vw, 500px"
            className="object-cover"
          />
        </div>
      ) : null}

      <article className="prose-maintenant mt-8 font-body text-text-1">
        {(() => {
          // V2.5.33 — priorité au HTML riche s'il est posé (déjà sanitizé
          // au save côté Server Action via sanitizeRichHtml). Sinon
          // fallback Markdown léger. Si les deux sont vides, message
          // placeholder éditable.
          const html = (e as { contenu_html?: string | null }).contenu_html ?? null;
          if (html !== null && html.trim() !== '') {
            return <RenduRiche valeurHtml={html} />;
          }
          if (e.contenu_md !== '') return <MarkdownLeger texte={e.contenu_md} />;
          return (
            <TexteEditableAdmin
              cle="journal.fiche.contenu_vide"
              valeurInitiale={contenuVide.valeurMd}
              estAdmin={estAdmin}
              libelle="message contenu vide"
              longueurMax={100}
            >
              {(t) => <p className="text-text-3 italic">{t}</p>}
            </TexteEditableAdmin>
          );
        })()}
      </article>

      {estAdmin ? (
        <section className="mt-12">
          <TexteEditableAdmin
            cle="journal.fiche.admin_section"
            valeurInitiale={adminSection.valeurMd}
            estAdmin={estAdmin}
            libelle="titre section administration"
            longueurMax={80}
          >
            {(t) => (
              <Heading niveau={2} apparenceComme={3}>
                {t}
              </Heading>
            )}
          </TexteEditableAdmin>
          <FormulaireMajEdition
            id={e.id}
            titreInitial={e.titre}
            sousTitreInitial={e.sous_titre ?? ''}
            contenuInitial={e.contenu_md}
            contenuHtmlInitial={(e as { contenu_html?: string | null }).contenu_html ?? null}
            imageInitial={e.image_couverture_url ?? ''}
            numeroInitial={e.numero}
            formatInitial={e.format === 'A4' ? 'A4' : 'A3'}
          />
        </section>
      ) : null}
    </Container>
  );
}
