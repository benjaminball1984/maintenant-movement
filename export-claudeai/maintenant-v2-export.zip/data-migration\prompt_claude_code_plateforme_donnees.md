# Super prompt Claude Code — Modèle de données unifié « profil qui s'enrichit »

> À copier-coller dans Claude Code, racine `C:\Users\Ben\projets\Maintenant\`.
> Stack : Next.js 14+, TypeScript strict, Supabase (Frankfurt). Plusieurs chantiers, dans l'ordre.
> Ne déclare un chantier terminé qu'une fois TOUS les états d'UI fonctionnels (règle d'exhaustivité).

---

## Vision d'ensemble

On bâtit un modèle de données où CHAQUE personne a UN profil unique (clé = email normalisé), et où chaque action qu'elle accomplit (signer une pétition, adhérer, s'abonner à la newsletter, proposer un hébergement, un covoiturage, participer à une mobilisation…) vient COMPLÉTER ce profil au bon endroit, sans jamais le dupliquer. Le profil se construit progressivement : une personne qui signe aujourd'hui puis adhère demain ne crée pas deux entrées, elle enrichit la même.

Principe RGPD central : TOUTES les données d'une personne sont accessibles et modifiables PAR ELLE (page « Mon compte / Mes données »), avec export et suppression possibles.

Règles permanentes du projet : non-invention (placeholders `[… À METTRE]` + lorem ipsum), pattern adaptateur (mock + stub réel), exhaustivité des états d'UI, séparation des couches (config, design tokens, i18n, composants, helpers), extensibilité native (ajouter un type d'action sans refactoring), livrables README + doc archi + guide maintenance.

---

## Fichiers d'import fournis (propres, prêts à importer tels quels)

1. `profils_unifies.csv` — 1 ligne/personne. Colonnes : `email`, `prenom`, `nom`, `telephone`, `code_postal`, `est_membre` (oui/non), `accepte_newsletter` (oui/non), `petitions_signees` (séparées par `|`), `nb_petitions`. ~15 800 personnes.
2. `signatures_detail.csv` — 1 ligne/(personne, pétition). Colonnes : `email`, `petition`, `code_postal`, `autorise_recontact_createur` (oui/non). ~17 700 signatures.
3. `abonnes_newsletter.csv` — vue filtrée des contactables. ~9 400 personnes.
4. `villes_signataires_top100.csv` / `villes_membres_top100.csv` — classements par commune.
5. `communes_france_geoloc.csv` — référentiel des ~35 000 communes + 45 arrondissements, avec `code_insee`, `latitude`, `longitude`.

Ces fichiers sont déjà nettoyés et dédoublonnés. Importe-les tels quels, sans retraitement.

---

## CHANTIER A — Le modèle de données central

### A.1 — Table `personnes` (le profil unifié)
Champs : `id`, `email` (unique, normalisé), `prenom`, `nom`, `telephone`, `code_postal`, `code_insee` (résolu depuis le CP), `est_membre` (dérivé), `accepte_newsletter`, `created_at`, `updated_at`.
- Tous les champs sauf email/id sont nullables : le profil se complète dans le temps.
- `email` porte une contrainte d'unicité. La normalisation (minuscules, suppression espaces) est une fonction réutilisable côté serveur, appelée à CHAQUE écriture.

### A.2 — Table générique `actions` (le cœur extensible)
Plutôt que coder en dur chaque type d'engagement, crée une table d'actions reliée à `personnes` :
`id`, `personne_id` (FK), `type_action` (enum extensible : `signature`, `adhesion`, `inscription_newsletter`, `offre_hebergement`, `offre_covoiturage`, `mobilisation`, …), `cible_id` (ex : id de la pétition pour une signature), `code_insee` (lieu de l'action, résolu depuis le CP saisi), `metadata` (JSONB pour les champs propres au type), `created_at`.
- Ajouter un nouveau type d'engagement = ajouter une valeur d'enum + un schéma de metadata. AUCUN refactoring des compteurs.
- Les compteurs de pétition ET de fiche commune se calculent depuis cette table unique (COUNT filtré par type + cible ou type + code_insee).

### A.3 — Consentements (attention RGPD, nuance importante)
DEUX niveaux distincts, à ne pas confondre :
- **Niveau personne** : `accepte_newsletter` (communications générales du mouvement).
- **Niveau action/signature** : `autorise_recontact_createur` stocké DANS la metadata de chaque action de type `signature`. Ce consentement VARIE par pétition (une personne peut autoriser le créateur d'une pétition mais pas d'une autre). Il ne remonte JAMAIS au profil.
- Conséquence d'accès : le créateur d'une pétition ne voit les coordonnées QUE des signataires dont l'action `signature` sur SA pétition porte `autorise_recontact_createur = true`. Implémente ce filtre comme une règle d'accès stricte (Row Level Security Supabase).
- On N'IMPORTE PAS de champ « publication du nom » : décision explicite, on ne prend pas ce risque.

---

## CHANTIER B — Les 5 pétitions

Toutes les 5 reçoivent leurs signatures importées depuis `signatures_detail.csv` (rattachement par le nom de pétition de la colonne `petition`).

| slug | titre | signataires |
|------|-------|------------:|
| `epstein` | Épstein | ~13 700 |
| `baranoux` | Baranoux | 1 813 |
| `antifasciste` | Antifasciste | 1 755 |
| `cuba` | Cuba | 326 |
| `ritchy` | Ritchy | 107 |

IMPORTANT sur Épstein : une pétition Épstein existe peut-être déjà sur la plateforme, mais ce n'est PAS la même que celle de l'import. Ne fusionne PAS avec une pétition existante et ne récupère PAS son id. Traite Épstein exactement comme les 4 autres : importe ses signatures vers la pétition Épstein cible.

Pour les pétitions à compléter : titres `[TITRE À METTRE — provisoire : X]`, descriptions en lorem ipsum, `objectif_signatures` = `[OBJECTIF À METTRE]`. La personne complétera plus tard.

---

## CHANTIER C — Fiche commune
Compteurs extensibles calculés depuis la table `actions` filtrée par `code_insee` : personnes inscrites, membres, signatures, offres d'hébergement, covoiturage, mobilisations… Référentiel = `communes_france_geoloc.csv` (35 000 communes + 45 arrondissements). Rattachement via CP → `code_insee` (table de correspondance ; un CP peut couvrir plusieurs communes, documenter la règle de résolution, ne pas deviner silencieusement).

---

## CHANTIER D — Espace « Mes données » (RGPD)
Page où la personne connectée voit et MODIFIE tout son profil : identité, coordonnées, code postal, consentement newsletter, et la liste de ses actions (pétitions signées avec, pour chacune, le réglage `autorise_recontact_createur` modifiable). Boutons d'export (télécharger mes données) et de suppression de compte. États d'UI : chargement, vide, nominal, erreur, confirmation de suppression.

---

## Ordre & garde-fous
1. CHANTIER A (modèle central) d'abord.
2. CHANTIER C : modèle de données avant l'UI.
3. Aucun état d'UI non fonctionnel avant de clore un chantier.
4. Si un point est ambigu, demander AVANT de coder.
5. Livrables : README + doc archi + guide maintenance.
